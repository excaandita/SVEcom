

<?php $__env->startSection('title'); ?>
    Portofolio - Sekolah Vokasi E-COM
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div style="margin-top: 96px">
        <div class="container">
            <form action="<?php echo e(url('/search')); ?>" type="get" class="mt-4">
                <div class="input-group w-100">
                    <span class="input-group-text" id="basic-addon1">
                        <img src="/images/search.svg" alt="">
                    </span>
                    <input name="query" class="form-control" type="search" placeholder="Mau Cari Apa?" aria-describedby="basic-addon1">
                </div>
            </form>

            <div class="row">
                <div class="col-12 mt-4">
                    <h5>All Portofolios</h5>
                </div>
            </div>
            <div class="row">
                <?php $incrementUsers = 0 ?>
                <?php if(request()->is('search') ): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div
                            class="col-6 col-md-3 col-lg-3"
                            data-aos="fade-up"
                            data-aos-delay="<?php echo e($incrementUsers+= 100); ?>"
                        >
                            <a href="<?php echo e(route('portofolio-detail', $skill->users_id)); ?>" class="text-decoration-none text-body">
                                <div class="card p-3 card-list">
                                    <h6><?php echo e($skill->name); ?></h6>
                                    <div class="d-flex flex-row justify-content-between">
                                        <p><?php echo e($skill->nama); ?></p>
                                        <p><?php echo e($skill->angkatan); ?></p>
                                    </div>
                                    <p><?php echo e($skill->jenis); ?></p>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center py-5" data-aos="fade-up"
                            data-aos-delay="100">
                            Skill Tidak Ditemukan
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div
                            class="col-6 col-md-3 col-lg-3"
                            data-aos="fade-up"
                            data-aos-delay="<?php echo e($incrementUsers+= 100); ?>"
                        >
                            <a href="<?php echo e(route('portofolio-detail', $user->id)); ?>" class="text-decoration-none text-body">
                                <div class="card p-3 card-list portfolio">
                                    <h6><?php echo e($user->name); ?></h6>
                                    <div class="d-flex flex-row justify-content-between">
                                        <p><?php echo e($user->nama); ?></p>
                                        <p><?php echo e($user->angkatan); ?></p>
                                    </div>
                                    <?php if(Str::length($user->deskripsi) > 70): ?>
                                        <div><?php echo Str::substr($user->deskripsi, 0, 70), "..."; ?></div>
                                    <?php else: ?>
                                        <div><?php echo $user->deskripsi; ?></div>
                                    <?php endif; ?>
                                </div>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center py-5" data-aos="fade-up"
                            data-aos-delay="100">
                            Tidak Ada Portofolio
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SVEcom\resources\views/pages/portofolio.blade.php ENDPATH**/ ?>