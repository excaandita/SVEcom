

<?php $__env->startSection('title'); ?>
Dashboard-Sekolah Vokasi E-COM
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="section-content section-dashboard-home" data-aos="fade-up">
        <div class="container-fluid">
            <div class="dashboard-heading">
                <h2 class="dashboard-title">Ringkasan statistik</h2>
                <p class="dashboard-subtitle">Rutin pantau perkembangan toko untuk tingkatkan penjualanmu</p>
            </div>
            <div class="dashboard-content">
                <div class="row">
                    <div class="col-md-6">
                        <div class="card text-white bg-info mb-3">
                            <div class="card-body">
                                <div class="dashboard-card-title">Pendapatan</div>
                                <div class="dashboard-card-subtitle">Rp. <?php echo e(number_format($revenue)); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card text-white bg-info mb-3">
                            <div class="card-body">
                                <div class="dashboard-card-title">Pesanan Baru</div>
                                <div class="dashboard-card-subtitle"><?php echo e($newrevenue); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="dashboard-heading">
                <h2 class="dashboard-title">Aktivitas Hari ini</h2>
                <p class="dashboard-subtitle">Aktivitas yang perlu kamu pantau untuk jaga kepuasan pembeli</p>
            </div>
            <div class="dashboard-content">
                <div class="row">
                    <div class="col-md-3">
                        <div class="card text-white bg-info mb-3">
                            <div class="card-body">
                                <div class="dashboard-card-title">Pesanan Diproses</div>
                                <div class="dashboard-card-subtitle"><?php echo e($pending); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-info mb-3">
                            <div class="card-body">
                                <div class="dashboard-card-title">Pesanan Dikirim</div>
                                <div class="dashboard-card-subtitle"><?php echo e($success); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-info mb-3">
                            <div class="card-body">
                                <div class="dashboard-card-title">Pesanan Selesai</div>
                                <div class="dashboard-card-subtitle"><?php echo e($done); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-info mb-3">
                            <div class="card-body">
                                <div class="dashboard-card-title">Pesanan Dibatalkan</div>
                                <div class="dashboard-card-subtitle"><?php echo e($canceled); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="dashboard-heading">
                <h3 class="dashboard-title">Recent Transactions</h3>
                <p class="dashboard-subtitle"></p>
            </div>
            <div class="dashboard-content">

                <?php $__empty_1 = true; $__currentLoopData = $recentlytransaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <ul class="list-group list-group-light">
                    <li class="list-group-item list-group-item-action justify-content-between align-items-center">
                        <div class="row">
                            <div class="col-md-1">
                                
                                
                                <svg xmlns="http://www.w3.org/2000/svg" width="70px" height="70px" fill="currentColor"
                                    class="bi bi-person" viewBox="0 0 16 16">
                                    <path
                                        d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z" />
                                </svg>
                            </div>
                            <div class="col-md-3">
                                <h5 class="fw-bold mb-1"><?php echo e($item->name); ?></h5>
                                <small class="text-muted mb-0"><?php echo e($item->email); ?></small>
                            </div>
                            <div class="col-md-2">
                                <h5 class="fw-bold mb-1"><?php echo e($item->roles); ?></h4>
                            </div>
                            <div class="col-md-2">
                                <h5 class="fw-bold mb-1"><?php echo e($item->transaction_status); ?></h4>
                            </div>
                            <div class="col-md-4">
                                <h5 class="fw-bold mb-1"><?php echo e($item->updated_at); ?></h4>
                            </div>
                        </div>
                    </li>

                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <ul class="list-group list-group-light">
                    <li class="list-group-item list-group-item-action justify-content-between align-items-center">
                        <div class="row">
                            <div class="col-md-1">
                                
                                
                                <svg xmlns="http://www.w3.org/2000/svg" width="70px" height="70px" fill="currentColor"
                                    class="bi bi-person" viewBox="0 0 16 16">
                                    <path
                                        d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z" />
                                </svg>
                            </div>
                            <div class="col-md-3">
                                <h5 class="fw-bold mb-1">Transaksi Kosong</h5>
                            </div>
                        </div>
                    </li>

                </ul>
                <?php endif; ?>
            </div>
            <div class="dashboard-heading">
                <h3 class="dashboard-title">Produk Terlaris di Tokomu</h3>
                <p class="dashboard-subtitle"></p>
            </div>
            <div class="dashboard-content">
                <div class="card">
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">No</th>
                                <th scope="col">Nama Produk</th>
                                <th scope="col">Harga</th>
                                <th scope="col">Terjual</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $i=0;
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $bestselling; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                            $i++;
                            ?>
                            <tr>
                                <th scope="row"><?php echo e($i); ?></th>
                                <td><?php echo e($i); ?></td>
                                <td>Rp. <?php echo e(number_format($item->price)); ?></td>
                                <td><?php echo e($item->count); ?></td>
                                <td>Aktif</td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td>Produk Kosong</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SVEcom\resources\views/pages/seller/dashboard.blade.php ENDPATH**/ ?>