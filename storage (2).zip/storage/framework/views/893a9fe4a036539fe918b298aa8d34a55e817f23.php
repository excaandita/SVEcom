

<?php $__env->startSection('title'); ?>
    Biodata Mahasiswa Sekolah Vokasi
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div
        class="section-content section-dashboard-home"
        data-aos="fade-up"
    >
        <div class="container-fluid">
            <div class="dashboard-heading">
                <h2 class="dashboard-title">BIODATA</h2>
                <p class="dashboard-subtitle">
                    <a class="btn btn-info px-5" href="<?php echo e(route('portofolio-biodata-create')); ?>" role="button">
                        Edit
                    </a>
                </p>
            </div>
            <div class="dashboard-content">
                <div class="row">
                    <div class="col-12">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="card">
                            <div class="card-body">
                                <h5>Deskripsi</h5>
                                <p><?php echo $user->deskripsi; ?></p>
                                <div class="row">
                                    <div class="col-6">
                                        <div class="d-flex">
                                            <h5>Tempat Lahir: </h5>
                                            <p class="ml-2"><?php echo e($user->tempat_lahir); ?></p>
                                        </div>
                                        <div class="d-flex">
                                            <h5>Tanggal Lahir: </h5>
                                            <p class="ml-2"><?php echo e($user->tanggal_lahir); ?></p>
                                        </div>
                                        <div class="d-flex">
                                            <h5>Alamat KTP: </h5>
                                            <p class="ml-2"><?php echo e($user->address_one); ?></p>
                                        </div>
                                        <div class="d-flex">
                                            <h5>Angkatan: </h5>
                                            <p class="ml-2"><?php echo e($user->angkatan); ?></p>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="d-flex">
                                            <h5>Fakultas: </h5>
                                            <p class="ml-2"><?php echo e($user->fakultas); ?></p>
                                        </div>
                                        <div class="d-flex">
                                            <h5>Program Studi: </h5>
                                            <?php if($prodi == null): ?>
                                                <p class="ml-2">Belum ada Program Studi</p>
                                            <?php else: ?>
                                                <p class="ml-2"><?php echo e($prodi->nama); ?></p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="d-flex">
                                            <h5>Alamat Solo: </h5>
                                            <p class="ml-2"><?php echo e($user->alamat_solo); ?></p>
                                        </div>
                                        <div class="d-flex">
                                            <h5>NIM: </h5>
                                            <p class="ml-2"><?php echo e($user->nim); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SVEcom\resources\views/pages/portofolio/biodata.blade.php ENDPATH**/ ?>