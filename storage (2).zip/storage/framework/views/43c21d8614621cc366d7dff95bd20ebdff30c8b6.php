

<?php $__env->startSection('title'); ?>
Dashboard-Sekolah Vokasi E-COM
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="section-content section-dashboard-home" data-aos="fade-up">
        <div class="container-fluid">
            <div class="dashboard-heading">
                <h2 class="dashboard-title">Admin Dashboard</h2>
                <p class="dashboard-subtitle">Sekolah Vokasi E-Commerce</p>
            </div>
            <div class="dashboard-content">
                <div class="row">
                    <div class="col-md-3">
                        <div class="card text-white bg-info mb-3">
                            <div class="card-body">
                                <div class="dashboard-card-title">Pesanan Diproses</div>
                                <div class="dashboard-card-subtitle"><?php echo e($pending); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-info mb-3">
                            <div class="card-body">
                                <div class="dashboard-card-title">Pesanan Dikirim</div>
                                <div class="dashboard-card-subtitle"><?php echo e($success); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-info mb-3">
                            <div class="card-body">
                                <div class="dashboard-card-title">Pesanan Diselesaikan</div>
                                <div class="dashboard-card-subtitle"><?php echo e($done); ?></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-info mb-3">
                            <div class="card-body">
                                <div class="dashboard-card-title">Pesanan Dibatalkan</div>
                                <div class="dashboard-card-subtitle"><?php echo e($canceled); ?></div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <div class="dashboard-heading">
                <h3 class="dashboard-title">Recent Transactions</h3>
            </div>
            <div class="dashboard-content">
                

                <?php $__currentLoopData = $recentlytransaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <ul class="list-group list-group-light">
                    <li class="list-group-item list-group-item-action justify-content-between align-items-center">
                        <div class="row">
                            <div class="col-md-1">
                                
                                
                                <svg xmlns="http://www.w3.org/2000/svg" width="70px" height="70px" fill="currentColor"
                                    class="bi bi-person" viewBox="0 0 16 16">
                                    <path
                                        d="M8 8a3 3 0 1 0 0-6 3 3 0 0 0 0 6zm2-3a2 2 0 1 1-4 0 2 2 0 0 1 4 0zm4 8c0 1-1 1-1 1H3s-1 0-1-1 1-4 6-4 6 3 6 4zm-1-.004c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664h10z" />
                                </svg>
                            </div>
                            <div class="col-md-3">
                                <h5 class="fw-bold mb-1"><?php echo e($item->name); ?></h5>
                                <small class="text-muted mb-0"><?php echo e($item->email); ?></small>
                            </div>
                            <div class="col-md-2">
                                <h5 class="fw-bold mb-1">Admin</h4>
                            </div>
                            <div class="col-md-2">
                                <h5 class="fw-bold mb-1"><?php echo e($item->transaction_status); ?></h4>
                            </div>
                            <div class="col-md-4">
                                <h5 class="fw-bold mb-1"><?php echo e($item->updated_at); ?></h4>
                            </div>
                        </div>
                    </li>

                </ul>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="dashboard-heading">
                <h3 class="dashboard-title">Portofolio Update</h3>
            </div>
            <div class="dashboard-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card text-white bg-info mb-3">
                            <div class="card-body">
                                <div class="dashboard-card-title">Verifikasi Request</div>
                                <div class="dashboard-card-subtitle"><?php echo e($portofoliobaru); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="dashboard-content">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-hover table-bordered scroll-horizontal-vertical w-100"
                                        id="crudTable">
                                        <thead class="bg-info">
                                            <tr>
                                                <th>ID</th>
                                                <th>Nama</th>
                                                <th>Jenis</th>
                                                <th>Lembaga</th>
                                                <th>No Sertifikat</th>
                                                <th>Status</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <div class="btn-group">
                                                <div class="dropdown">
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item"
                                                            href="' . route('sertifikat.edit', $item->id) .'">
                                                            Edit
                                                        </a>
                                                        <form action="'. route('sertifikat.destroy', $item->id) .'"
                                                            method="POST">
                                                            '. method_field('delete'). csrf_field() .'
                                                            <button type="submit" class="dropdown-item text-danger">
                                                                Hapus
                                                            </button>

                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('addon-script'); ?>
<script>
    var datatable = $('#crudTable').DataTable({
            processing: true,
            serverSide: true,
            ordering: [[6, "desc"],true],
            searching: false,
            ajax: {
                url: '<?php echo url()->current(); ?>',
            },
            columns: [
                { data: 'id_skill', name: 'id_skill' },
                { data: 'name', name: 'name' },
                { data: 'jenis', name: 'jenis' },
                { data: 'lembaga', name: 'lembaga' },
                { data: 'no_sertifikat', name: 'no_sertifikat' },
                { data: 'status', name: 'status' },
                {
                    data: 'action',
                    name: 'action',
                    orderable: false,
                    searchable:false,
                    widht: '15%',
                },
            ]
        })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SVEcom\resources\views/pages/admin/dashboard.blade.php ENDPATH**/ ?>