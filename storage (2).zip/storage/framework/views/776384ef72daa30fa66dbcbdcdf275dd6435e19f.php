

<?php $__env->startSection('title'); ?>
    Dashboard-Sekolah Vokasi E-COM
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(session('error')): ?>
     <div class="alert alert-danger">
         <?php echo e(session('error')); ?>

     </div>
  <?php endif; ?>

<div
    class="section-content section-dashboard-home"
    data-aos="fade-up"
    >
    <div class="container-fluid">
        <div class="dashboard-heading">
            <h2 class="dashboard-title">Admin Dashboard - User</h2>
            <p class="dashboard-subtitle">Sekolah Vokasi E-Commerce</p>
        </div>
        <div class="dashboard-content">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                            
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered scroll-horizontal-vertical w-100" id="crudTable">
                                    <thead class="bg-info">
                                        <tr>
                                            <th>ID</th>
                                            <th>Nama</th>
                                            <th>Email</th>
                                            <th>Roles</th>
                                            <th>Status</th>
                                           
                                        </tr>
                                    </thead>
                                    <tbody>

                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row" class="text-center"><?php echo e($loop->iteration); ?></th>
                    <td scope="row" class="text-center" hidden><?php echo e($user->id); ?></td>
                    <td scope="row" class="text-center"><?php echo e($user->name); ?></td>
                    <td scope="row" class="text-center"><?php echo e($user->email); ?></td>
                    <td scope="row" class="text-center"><?php echo e($user->roles); ?></td>
                    <td scope="row" class="text-center">
                          <?php if($user->is_active == 0): ?>
                            <a href="<?php echo e(route ('update-status-baru', ['id' => $user->id, 'status_code' => 1])); ?>" class="btn btn-danger mb-3" >Tidak Aktif<i class="fas fa-ban"></i></a>
                          <?php else: ?>
                            <a href="<?php echo e(route ('update-status-baru', ['id' => $user->id, 'status_code' => 0])); ?>" class="btn btn-success m-3" >Aktif<i class="fas fa-check"></i></a>
                          <?php endif; ?>
                    </td>
                  
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<script>
    $('.delete').click(function(){

        var id = $(this).attr('user-id')
        var user_num = $(this).attr('user-num')

        Swal.fire({
          title: "Apakah anda yakin?",
          text: "Hapus data user "+user_num+"??",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Ya, hapus!'
        }).then((result) => {
          if (result.isConfirmed) {
            window.location = "/user-baru/"+id+"/delete";  
            Swal.fire(
              'Berhasil!',
              'Data berhasil dihapus ',
              'success'
            )
          }
        })
    });
</script>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SVEcom\resources\views/pages/admin/user_baru/index.blade.php ENDPATH**/ ?>