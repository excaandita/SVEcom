

<?php $__env->startSection('title'); ?>
    Kategori - Sekolah Vokasi E-COM
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-content page-home" style="margin-top: 80px">
  
  <section class="store-new-products">
    <div class="container-fluid" data-aos="fade-up">
        <div class="row">
            <div class="col-md-8 offset-md-2 mb-3">
              <h2 class="text-center display-4">PRODUK</h2> 
              <form action="<?php echo e(route('listproduct')); ?>" method="GET">
                <div class="input-group">
                  <input type="search" name="search" value="<?php echo e(request()->get('search')); ?>" class="form-control form-control-lg" placeholder="Cari Produk Pilihanmu">
                    <div class="input-group-append">
                    <button type="submit" class="btn btn-lg btn-info">
                    Search
                    </button>
                    </div>
                </div>
              </form>
            </div>
        </div>
        <div class="container">
      <div class="row">
        <div class="col-12" data-aos="fade-up">
          <h5>Semua Produk</h5>
        </div>
      </div>
      <div class="row">
      <!-- batas new Product-->
        <?php $incrementProduct = 0 ?>
          <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div
            class="col-4 col-md-4 col-lg-3 mt-3"
            data-aos="fade-up"
            data-aos-delay="<?php echo e($incrementProduct+= 100); ?>"
            >
              <a href="<?php echo e(route('detailproduk', $product->slug)); ?>" class="component-products d-block">
                <div class="products-thumbnail">
                  <div
                    class="products-image"
                    style="
                      <?php if($product->galleries->count()): ?>
                        background-image: url('<?php echo e(Storage::url($product->galleries->first()->photos)); ?>')
                      <?php else: ?>
                        background-color: #17A2B8
                      <?php endif; ?>
                    "
                  ></div>
                </div>
                <div class="products-text"><?php echo e($product->name); ?></div>
                <div class="products-price">Rp. <?php echo e(number_format($product->price)); ?></div>
              </a>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center py-5" data-aos="fade-up"
            data-aos-delay="100">
              Tidak ada produk
            </div>
          <?php endif; ?>
      <!-- batas new Product-->
      </div>
    </div>
  </section>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\SVEcom\resources\views/pages/listproduct.blade.php ENDPATH**/ ?>